test.bat - starts one import thread.
start_importWorkers.bat - starts 24 importing threads.

quatrics.py - lib to get data from quatrics.py 
createTablesDynamoDb.py - create fresh tables in DynamoDb
importQuatricsToDynPosgre.py - main import logic


Do not forget to reduce read/write capacity in dynamo db when importing is done.
