import io
import csv
import json
from collections import OrderedDict
import collections

import requests
import os
import sys

import xml.etree.ElementTree as ET

from requests.exceptions import ConnectionError, Timeout, TooManyRedirects, HTTPError

__version__ = "0.0.1"

if sys.version_info >= (3, 0):
    STR = (str, )
    from io import StringIO
    from io import BytesIO
else:
    STR = (str, unicode)
    from StringIO import StringIO

class quatrics(object):
    # http://docs.python-requests.org/en/master/user/advanced/#ssl-cert-verification
    requests_kwargs = dict()

    def __init__(self, user=None, token=None, api_version="2.5"):
        self.user = user
        self.token = token
        self.default_api_version = api_version
        # Version must be a string, not an integer or float
        assert self.default_api_version, STR
        self.last_error_message = None
        self.last_status_code = None
        self.last_url = None
        self.last_data = None
        self.json_response = None
        self.r = None  # requests.Response object, for debugging purpose
        self.response = None  # For debugging purpose
        self.url = None # For debugging purpose

    def __str__(self):
        return self.user

    def __repr__(self):
        return "%s(%r)" % (self.__class__, self.__dict__)

    def getAllQuestions(self, SurveyID):
        urlas = "https://co1.qualtrics.com/API/v3/survey-definitions/"+SurveyID+"/questions"
        # print(urlas)
        response = self.request3(urlas, method = "get")
        # print(response)
        if response != None:
            json_response = json.loads(response.text, object_pairs_hook=collections.OrderedDict)
            return json_response["result"]["elements"]
        else:
            return dict()

    def request3(self, url, method="post", stream=False, data=None):
        self.last_url = url
        self.last_data = None
        self.r = None
        self.response = None
        self.last_error_message = "Not yet set by request3 function"
        if data is None:
            data = dict()
        data_json = json.dumps(data)
        headers = {
            "X-API-TOKEN": self.token,
            "Content-Type": "application/json"
        }
        try:
            if method == "post":
                self.last_data = data
                r = requests.post(url, data=data_json, headers=headers)
            elif method == "get":
                r = requests.get(url, headers=headers)
            else:
                raise NotImplementedError("method %s is not supported" % method)
        except (ConnectionError, Timeout, TooManyRedirects, HTTPError) as e:
            self.last_error_message = str(e)
            return None
        self.r = r
        self.response = r.text   # Keep this for backward compatibility with previous versions
        try:
            self.json_response = r.json()
        except:
            self.json_response = None
        if r.status_code != 200:
            # HTTP server error: 404, 500 etc
            # Apparently http code 401 Unauthorized is returned when incorrect token is provided
            self.last_error_message = "HTTP Code %s" % r.status_code
            try:
                if "error" in self.json_response["meta"]:
                    self.last_error_message = self.json_response["meta"]["error"]["errorMessage"]
                    print(self.last_error_message)
                    return None
            except:
                # Mailformed response from the server
                pass
            return None
        return r


    def request(self, Request, Product='RS', post_data=None, post_files=None, **kwargs):
        Version = kwargs.pop("Version", self.default_api_version)
        # Version must be a string, not an integer or float
        assert Version, STR

        # Handling for Multi Product API calls
        if self.url:
            # Force URL, for use in unittests.
            url = self.url
        elif Product == 'RS':
            url = "https://survey.qualtrics.com/WRAPI/ControlPanel/api.php"
        elif Product == 'TA':
            url = "https://survey.qualtrics.com/WRAPI/Contacts/api.php"
        else:
            raise NotImplementedError('Please specify a valid product api')

        # Special case for handling embedded data
        ed = kwargs.pop("ED", None)

        # http://stackoverflow.com/questions/38987/how-can-i-merge-two-python-dictionaries-in-a-single-expression
        params = {"User": self.user,
                       "Token": self.token,
                       "Format": "JSON",
                       "Version": Version,
                       "Request": Request,
                       }
        # Python 2 and 3 compatible dictionary merge
        for item in kwargs:
            params[item] = kwargs[item]

        if ed is not None:
            for key in ed:
                params["ED[%s]" % key] = ed[key]

        self.json_response = None
        self.last_error_message = "Not yet set by request function"
        self.last_status_code = None
        
        try:
            if post_data:
                r = requests.post(url,
                                  data=post_data,
                                  params=params,
                                  **self.requests_kwargs)
            elif post_files:
                r = requests.post(url,
                                  files=post_files,
                                  params=params,
                                  **self.requests_kwargs)
            else:
                r = requests.get(
                    url,
                    params=params,
                    **self.requests_kwargs
                )
        except (ConnectionError, Timeout, TooManyRedirects, HTTPError) as e:
            self.last_url = ""
            self.response = None
            self.last_error_message = str(e)
            return None

        self.last_url = r.url
        self.response = r.text
        self.last_status_code = r.status_code
        if r.status_code == 403:
            self.last_error_message = "API Error: HTTP Code %s (Forbidden)" % r.status_code
            return None
        if r.status_code == 401 and Request == "getSurvey":
            # I'm don't know if 401 is returned for requests other than getSurvey
            self.last_error_message = "API Error: HTTP Code %s (Unauthorized)" % r.status_code
            return None

        if r.status_code == 500 and Request == "getSurvey":
            root = ET.fromstring(r.text)
            try:
                self.last_error_message = root.find("Meta").find("ErrorMessage").text
            except AttributeError:
                # 'NoneType' object has no attribute 'text'
                self.last_error_message = "Internal server error"
            return None

        try:
            if Request == "getLegacyResponseData":
                # Preserve order of responses and fields in each response using OrderedDict
                json_response = json.loads(r.text, object_pairs_hook=collections.OrderedDict)
            else:
                # Don't not use OrderedDict for simplicity.
                json_response = json.loads(r.text)
        except ValueError:
            # If the data being deserialized is not a valid JSON document, a ValueError will be raised.
            self.json_response = None
            if "Format" not in kwargs:
                self.last_error_message = "Unexpected response from Qualtrics: not a JSON document"
                return None
            else:
                # Special case - getSurvey. That request has a custom response format (xml).
                # It does not follow the default response format
                self.last_error_message = None
                return r.text

        self.json_response = json_response
        # Sanity check.
        if (Request == "getLegacyResponseData" or Request == "getPanel" or Request == 
            "getListContacts") and "Meta" not in json_response:
            # Special cases - getLegacyResponseData, getPanel and getListContacts
            # Success
            self.last_error_message = None
            return json_response
        if "Meta" not in json_response:
            # Should never happen
            self.last_error_message = "Unexpected response from Qualtrics: no Meta key in JSON response"
            return None
        if "Status" not in json_response["Meta"]:
            # Should never happen
            self.last_error_message = "Unexpected response from Qualtrics: no Status key in JSON response"
            return None

        if json_response["Meta"]["Status"] == "Success":
            self.last_error_message = None
            return json_response

        # If error happens, it returns JSON object too
        # Error message is in json_response["Meta"]["ErrorMessage"]
        self.last_error_message = json_response["Meta"]["ErrorMessage"]
        return None

    def getSurveys(self, **kwargs):
        response = self.request("getSurveys", **kwargs)
        # print response
        surveys = None
        if response:
            surveys = OrderedDict()
            for survey in response["Result"]["Surveys"]:
                surveys[survey['SurveyID']] = survey
        return surveys

    def getSurvey(self, SurveyID):
        return self.request("getSurvey", SurveyID=SurveyID, Format=None)

    def getLegacyResponseData(
            self,
            SurveyID,
            LastResponseID=None,
            Limit=None,
            ResponseID=None,
            ResponseSetID=None,
            SubgroupID=None,
            StartDate=None,
            EndDate=None,
            Questions=None,
            Labels=None,
            ExportTags=None,
            ExportQuestionIDs=None,
            LocalTime=None,
            UnansweredRecode=None,
            PanelID=None,
            ResponsesInProgress=None,
            LocationData=None,
            **kwargs):
        return self.request(
            "getLegacyResponseData",
            SurveyID=SurveyID,
            LastResponseID=LastResponseID,
            Limit=Limit,
            ResponseID=ResponseID,
            ResponseSetID=ResponseSetID,
            SubgroupID=SubgroupID,
            StartDate=StartDate,
            EndDate=EndDate,
            Questions=Questions,
            Labels=Labels,
            ExportTags=ExportTags,
            ExportQuestionIDs=ExportQuestionIDs,
            LocalTime=LocalTime,
            UnansweredRecode=UnansweredRecode,
            PanelID=PanelID,
            ResponsesInProgress=ResponsesInProgress,
            LocationData=LocationData,
            **kwargs)

    def getResponse(self, SurveyID, ResponseID, **kwargs):
        response = self.getLegacyResponseData(SurveyID=SurveyID, ResponseID=ResponseID, **kwargs)
        # Don't do "if not response:" - because getLegacyResponseData can return empty dict in some cases
        if response is None:
            return None
        if ResponseID not in response:
            # Should never happen
            self.last_error_message = "Qualtrics error: ResponseID %s not in response (probably deleted)" % ResponseID
            return None
        return response[ResponseID]

    def getPanels(self, LibraryID):
        response = self.request("getPanels", LibraryID=LibraryID)
        if not response:
            return None
        return response["Result"]["Panels"]

    def getPanel(self, LibraryID, PanelID, EmbeddedData=None, LastRecipientID=None, NumberOfRecords=None,
                 ExportLanguage=None, Unsubscribed=None, Subscribed=None, **kwargs):
        return self.request(
            "getPanel",
            LibraryID=LibraryID,
            PanelID=PanelID,
            EmbeddedData=EmbeddedData,
            LastRecipientID=LastRecipientID,
            NumberOfRecords=NumberOfRecords,
            ExportLanguage=ExportLanguage,
            Unsubscribed=Unsubscribed,
            Subscribed=Subscribed,
            **kwargs
        )

    def getAllSubscriptions(self):
        return self.request(
            "getAllSubscriptions",
        )

    def generate_unique_survey_link(
            self,
            SurveyID,
            LibraryID,
            PanelID,
            DistributionID,
            FirstName,
            LastName,
            Email,
            ExternalDataRef="",
            Language="English",
            EmbeddedData=None
    ):

        assert isinstance(EmbeddedData, (dict, type(None)))
        assert isinstance(SurveyID, STR)
        assert isinstance(DistributionID, STR)

        if EmbeddedData is None:
            EmbeddedData = {}
        recipient_id = self.addRecipient(LibraryID, PanelID, FirstName=FirstName, LastName=LastName, Email=Email, ExternalDataRef=ExternalDataRef, Language=Language, ED=EmbeddedData)
        if recipient_id is None:
            # last_error_message is set by addRecipient function
            return None
        if "_" not in SurveyID:
            self.last_error_message = "Invalid SurveyID format (must be SV_xxxxxxxxxx)"
            return None

        if "_" not in DistributionID:
            self.last_error_message = "Invalid DistributionID format (must be EMD_xxxxxxxxxx)"
            return None

        link = DistributionID.split("_")[1] + "_" + SurveyID.split("_")[1] + "_" + recipient_id

        link = "http://new.qualtrics.com/SE?Q_DL=%s" % link

        return link

