import sys
import os
from pyqualtrics import Qualtrics

if os.path.exists('.env'):
    for line in open(".env"):
        var = line.strip().split('=')
        if len(var) == 2:
            os.environ[var[0]] = var[1]


try:
    # Python 2.7
    input = raw_input
except NameError:
    # Python 3.5
    pass


def main(argv):
    kwargs = {}
    iterator = iter(argv)
    executable = next(iterator)  # argv[0]
    try:
        command = next(iterator)     # argv[1]
    except StopIteration:
        print("The name of the API call to be made is required")
        return None

    user = None
    if "QUALTRICS_USER" not in os.environ:
        user = input("Enter Qualtrics username: ")

    token = None
    if "QUALTRICS_TOKEN" not in os.environ:
        token = input("Enter Qualtrics token: ")

    qualtrics = Qualtrics(user, token)
    method = getattr(qualtrics, command)
    if not method:
        print("%s API call is not implement" % method)
        return None

    for option in argv:
        try:
            arg, value = option.split("=")
            kwargs[arg] = value
        except ValueError:
            # Ignore parameter in wrong format
            pass
    return method(**kwargs)


if __name__ == "__main__":
    # main(["", "createPanel", "library_id=1", "name=b"])
    result = main(sys.argv)
    if result is None:
        print("Error executing API Call")
    else:
        print("Success: %s" % result)
