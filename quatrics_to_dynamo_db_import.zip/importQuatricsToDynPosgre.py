from quatrics import quatrics
import psycopg2
import datetime
import boto3
import json
import decimal
from boto3.dynamodb.conditions import Key, Attr
import itertools
import typing
import lxml.html
import time
import re
import random
import argparse
import uuid

parser = argparse.ArgumentParser(description='Import data to dynamo db table from Qualtrics API')
parser.add_argument('worker_count', type=int, help='Total Worker Count to share data between')
parser.add_argument('worker_id', type=int, help='Worker ID')
args = parser.parse_args()
print(args)


QUALTRICS_USER = "appadmin"
QUALTRICS_TOKEN = "erUHAXeu9eLsJY2aAgDPy9Ei53H0vSyPYC2TFg22"
QUALTRICS_SURVEY_ID = "SV_4O40HF9W5miimod"


qualtrics = quatrics(QUALTRICS_USER, QUALTRICS_TOKEN)

region = "us-west-2"
dynamoDbEndpoint = "https://dynamodb." + region + ".amazonaws.com"
dynamodb = boto3.resource('dynamodb', region_name=region, endpoint_url=dynamoDbEndpoint)
table = dynamodb.Table("responses")

postgreConn = None

db_user = "mt_mark"
db_host = "ec2-35-171-12-188.compute-1.amazonaws.com"
db_name = "d2s5p9qouci5nq"
db_pass = "p20b23186ddc5a7c477ca9728fbbe75b20d07e295fc83076e6ad3adb4a782a556"

alarming_words = open('alarming_words.txt','r').read().split("\n")
filtering_words = open('swear_words.txt','r').read().split("\n")

def isAlarming(org_text):
    if org_text == None:
        return False
    res = any(ele in org_text.lower().split() for ele in alarming_words)
    return res

def isFiltering(org_text):
    str1 = str("[ ]")
    filteredText = filterText(org_text)
    return str(filteredText).find('[ ]') > -1
    
def filterText(org_text):
    tmpText = str(org_text).lower()
    for tag in filtering_words:
       tmpText = re.sub(r'\b' + tag + r'\b', '[ ]', tmpText)
    return tmpText

def randomNumber():
    return str(random.randint(100000000000,999999999999))

def updateResponses(postgreConn, survey_guid, response_count):
    lastImportedResponseGuid = getLastImportedResponseGuid(survey_guid)
    responsesOld = list(iterate_paged_results(getResponses, survey_guid))
    responsesOld_count = len(responsesOld)
    if responsesOld_count>0 and response_count == responsesOld_count:
        print("Responses are already imported for survey:  survey_guid = ", survey_guid)
    else:
        print("Imporing responses...")
        lastImportedResponseGuid = importResponses(postgreConn, survey_guid, lastImportedResponseGuid, response_count)
    print("Returning lastImportedResponseGuid: ", lastImportedResponseGuid)
    return lastImportedResponseGuid

def getLastImportedResponseGuid(survey_guid):
    print("Calling... getLastImportedResponseGuid: ", survey_guid)
    table = dynamodb.Table('new_surveys')
    pe = "survey_guid, last_response_guid"
    fe = Key('survey_guid').eq(survey_guid)
    query_params = { 'KeyConditionExpression': fe, 'ProjectionExpression': pe}
    response = table.query(**query_params)
    return response["Items"][0]["last_response_guid"]

def getResponses(survey_guid, ExclusiveStartKey = None):
    table = dynamodb.Table('new_responses')
    pe = "guid"
    fe = Key('survey_guid').eq(survey_guid)
    query_params = { 'KeyConditionExpression': fe, 'ProjectionExpression': pe}
    if ExclusiveStartKey:
        query_params['ExclusiveStartKey'] = ExclusiveStartKey
    response = table.query(**query_params)
    return response

def importResponses(postgreConn, survey_guid, lastImportedResponseGuid, response_count):
    allQuestions = qualtrics.getAllQuestions(survey_guid)
    lastResponseIdToReturn = lastImportedResponseGuid
    table = dynamodb.Table('new_responses')
    print("          Starting importResponses.......", survey_guid, lastImportedResponseGuid)
    
    limit = 10
    offSet = 0
    with table.batch_writer() as batch:
        while offSet < response_count+1:
            if (offSet - 10 < response_count+1):
                offSet = offSet + limit
                print('Importing response...  -> ', offSet, " of ", response_count)
                if lastImportedResponseGuid == None:
                    responses = qualtrics.getLegacyResponseData(SurveyID=survey_guid, Labels=1, Limit=limit, Offset=offSet-10)
                    responsesWithIdz = qualtrics.getLegacyResponseData(SurveyID=survey_guid, Labels=0, Limit=limit, Offset=offSet-10)
                else:
                    responses = qualtrics.getLegacyResponseData(LastResponseID = lastImportedResponseGuid, SurveyID=survey_guid, Labels=1, Limit=limit, Offset=offSet-10)
                    responsesWithIdz = qualtrics.getLegacyResponseData(LastResponseID = lastImportedResponseGuid, SurveyID=survey_guid, Labels=0, Limit=limit, Offset=offSet-10)
                if responses is None or not responses:
                    if lastImportedResponseGuid != None:
                        print("No new responses in SurveyID = ", survey_guid, " using LastResponseID: ", lastImportedResponseGuid)
                    return lastResponseIdToReturn
                for response_id, response in responses.items():
                    response_with_idz = findResponseWithIdz(response_id, responsesWithIdz)
                    responderId = response.get('Responder ID', None)
                    if responderId == "":
                        responderId = None
                    responder_type = response.get('Staff ID', None)
                    source = None
                    if responder_type != None:
                        responder_type = "Staff"
                        source = "staff"
                    else:
                        responder_type = "Student"
                        source = "student"
                        
                    external_ref = response.get('ExternalDataReference', None)
                    if external_ref == "":
                        external_ref = None
                    segment = response.get('Segment', None)
                    if segment == "":
                        segment = None
                    
                    school = response.get('School', None)
                    if school == "":
                        school = None
                    
                    grade = response.get('Grade', None)
                    if grade == "":
                        grade = None
                    
                    gender = response.get('Gender', None)
                    if gender == "":
                        gender = None
                    jsonDump = json.dumps(response, indent=1, default=str)
                    if len(jsonDump) > 360000:
                        jsonDump = jsonDump[0:360000]
                    batch.put_item(
                    Item={
                        'survey_guid': survey_guid,
                        'response_guid': response_id,
                        'school': school,
                        'full_name': response.get('Name', None),
                        'gender': gender,
                        'grade': grade,
                        'segment': segment,
                        'finished': response.get('Finished', None),
                        'responder_id': responderId,
                        'external_data_reference': external_ref,
                        'start_date': response.get('StartDate', None),
                        'end_date': response.get('EndDate', None),
                        'created_at': datetime.datetime.now().isoformat(),
                        'survey_response': jsonDump,
                        'responder_type': responder_type,
                        'source': source
                    }
                    )
                    #time.sleep(0.10)
                    processResponseAswers(postgreConn, survey_guid, response_id, response, response_with_idz, allQuestions, response.get('Name', None), responderId)
                    lastResponseIdToReturn = response_id
    return lastResponseIdToReturn;

def processResponseAswers(postgreConn, survey_guid, response_id, response, response_with_idz, allQuestions, studentFullName, studentId):
    print("............   Importing aswers for response............ -> ", response_id)
    table = dynamodb.Table('new_response_answers')
    i = 0
    allTeachers = {}
    all_mentioned_idz = {}
    all_mentioned_numbers = {}
    
    with table.batch_writer() as batch:
        for r in response:
            if r.startswith("Teacher"):
                allTeachers[str(response[r]).lower()] = 0
                all_mentioned_idz[str(response[r]).lower()] = None
                all_mentioned_numbers[str(response[r]).lower()] = None
                
            if r.startswith("Q"):
                for q in allQuestions:
                    rq = r.split('_')[0]
                    dataExportTag = q.get('DataExportTag', None)
                    choise_id = None
                    if rq == dataExportTag and response[r] != "":
                        qusetion_text = parseHtml(q["QuestionText"])
                        if qusetion_text == "":
                            qusetion_text = None
                        response_text = parseHtml(response[r])
                        if response_text == "":
                            response_text = None
                        response_text_save = filterText(response_text)
                        if len(response_text_save) > 340000:
                            response_text_save = response_text[0:340000]
                        teacherKey = str(response[r]).lower();
                        
                        if (len(teacherKey) < 64 and teacherKey in allTeachers):
                            allTeachers[teacherKey] = allTeachers[teacherKey] + 1
                            all_mentioned_idz[teacherKey] = q["QuestionID"]
                            all_mentioned_numbers[teacherKey] = dataExportTag
                        
                        if (q.get('Choices', None) != None and response_with_idz != None):
                            choise_id = response_with_idz[r]
                            
                        batch.put_item(Item={
                            'survey_guid': survey_guid,
                            'order': i,
                            'response_guid': response_id,
                            'response_question_id': r,
                            'q_id': q["QuestionID"],
                            'q_number': dataExportTag,
                            'response_text': response_text_save,
                            'q_text': qusetion_text,
                            'filtering_ind': isFiltering(response_text),
                            'alarming_ind': isAlarming(response_text),
                            'created_at': datetime.datetime.now().isoformat(),
                            'updated_at': datetime.datetime.now().isoformat(),
                            'choise_id': choise_id
                        }
                        )
                        i = i + 1
                    #time.sleep(0.05)
    print("Creating student_stuff_relationship")
    create_relationship_records(postgreConn, survey_guid, response_id, allTeachers, all_mentioned_idz, all_mentioned_numbers, studentFullName, studentId)
    


def update_survey(
    guid,
    name, # Survey name?
    status, # Active or Inactive
    type,
    last_modified,
    last_activated,
    number_of_responses,
    last_response_guid = None,
    descr = None,
    survey_version_id = None,
    created_at = datetime.datetime.now().isoformat(),
    updated_at = datetime.datetime.now().isoformat(),
    group_id = None
    ):
    table = dynamodb.Table('new_surveys')
    print("Inserting to new_survey...")
    table.put_item(
    Item={
        'survey_guid': guid,
        'name': name,
        'status': status,
        'type': type,
        'number_of_responses': number_of_responses,
        'descr': descr,
        'last_response_guid': last_response_guid,
        'created_at': created_at,
        'updated_at': updated_at,
        'last_modified': last_modified,
        'last_activated': last_activated
    }
    )
    #time.sleep(0.05)
    print ("Record inserted successfully into new_surveys")


def updateQuestions(survey_guid, postgreConn):
    print("    Inserting to survey_questions...")
    allQuestions = qualtrics.getAllQuestions(survey_guid)
    questions = list(iterate_paged_results(getQuestions, survey_guid))
    questions_count = len(questions)
    if questions_count>0 and questions_count == len(allQuestions):
        print("Questions are already imported for survey:  survey_guid = ", survey_guid)
    else:
        print("Imporing questions...")
        importQuestions(survey_guid, postgreConn)
    print("    Records inserted successfully into survey_questions")

def importQuestions(survey_guid, postgreConn):
    print("Downloading questions...")
    # print("Getting question info from Postgres...")
    postgress_survey_data = get_survey_data(postgreConn, survey_guid)
    # print('postgress_survey_data: ', postgress_survey_data)
    
    try:
        survey_version_id = postgress_survey_data[0][7]
    except:
        survey_version_id = -1
    # print('Survey version = ', survey_version_id)
    
    important_questions = get_relationship_questions(postgreConn, survey_version_id)
    # print('Important questions: ', important_questions)
    
    allQuestions = qualtrics.getAllQuestions(survey_guid)
    table = dynamodb.Table('new_survey_questions')
    print("Inserting to new_survey_questions...")
    i = 1
    with table.batch_writer() as batch:
        for q in allQuestions:
            #print("------------------------------------------------")
            # print(q)
            # print("QuestionText: ",parseHtml(q["QuestionText"]))
            # print("DataExportTag: ",q["DataExportTag"])
            # print("QuestionType: ", q["QuestionType"])
            # print("QuestionID: ", q["QuestionID"])
            choices_json = json.dumps(q.get('Choices', None), indent=1, default=str)
            q_number = q.get('DataExportTag', None)
            if q_number == "":
                q_number = q.get("QuestionID", None)
            text = q.get("QuestionText", None)
            text1 = parseHtml(text)
            if text1 == "":
                text1 = "null"
            batch.put_item(
            Item={
            'survey_guid': survey_guid,
            'q_number': q_number,
            'q_id': q.get("QuestionID", None),
            'text': text1,
            'type': q.get("QuestionType", None),
            'order': i,
            'choices': choices_json,
            'created_at': datetime.datetime.now().isoformat()
            }
            )
            relationship_type = None
            important_question_data = question_belongs(important_questions, q_number, q.get("QuestionID", None))
            if important_question_data != None:
                print('Question is important!')
                relationship_type = important_question_data[2]

            i = i + 1
        #time.sleep(0.05)
        #print("------------------------------------------------")
    print("Questions imported!")
    
def getQuestions(survey_guid, ExclusiveStartKey = None):
    print("Getting questions: ", survey_guid, ExclusiveStartKey)
    table = dynamodb.Table('new_survey_questions')
    pe = "survey_guid"
    fe = Key('survey_guid').eq(survey_guid)
    query_params = { 'KeyConditionExpression': fe, 'ProjectionExpression': pe}
    if ExclusiveStartKey:
        query_params['ExclusiveStartKey'] = ExclusiveStartKey
    response = table.query(**query_params)
    return response
    

def lambda_handler(event, context):
    INSTANCE_ID = args.worker_id
    TOTAL_INSTANCE = args.worker_count
    COUNT_PER_INSTANCE = 0

    print('Main activated -> ', INSTANCE_ID, ' of ', TOTAL_INSTANCE)

    allSurveys_Q = qualtrics.getSurveys()
    # time.sleep(10)
    print('Total items: ', len(allSurveys_Q.items()))
    COUNT_PER_INSTANCE = int(len(allSurveys_Q.items()) / TOTAL_INSTANCE) + (len(allSurveys_Q.items()) % TOTAL_INSTANCE > 0)

    
    IMPORT_FROM = COUNT_PER_INSTANCE * INSTANCE_ID
    IMPORT_TO = IMPORT_FROM + COUNT_PER_INSTANCE
    print('IMPORT_FROM = ', IMPORT_FROM, ' IMPORT_TO = ', IMPORT_TO, ' COUNT_PER_INSTANCE = ', COUNT_PER_INSTANCE)
    
    # surveys = list(iterate_paged_results(get_surveys))
    # for survey in surveys:
       # print(survey)
       # survey_id = survey["id"]
       # survey_guid = survey["guid"]
       # last_response_guid = survey.get( 'last_response_guid', None )
       # survey_version_id = survey.get( 'survey_version_id', None )
       # print('last_response_guid = ', last_response_guid)
       # if (survey_version_id is None):
           # print("Inserting new survey version...")
       # surveyDetail_Q = allSurveys_Q[QUALTRICS_SURVEY_ID]
       # print("Survey detail: ", surveyDetail_Q)
       # updateQuestions(survey_id, survey_guid, survey_version_id)
       # break;
    # connn.close()
#responses = qualtrics.getLegacyResponseData(SurveyID=QUALTRICS_SURVEY_ID)
#for response_id, response in responses.items():
#    print (response_id)
#    print (response['Finished'])

    INDEX = 0
    total_responses_count = 0
    
    postgreConn = connect()

    for response_id, r in allSurveys_Q.items():
        year = str(str(r['SurveyName']).strip())[0:4]
        print("Year: ", year)
        yearInt = 0
        try:
            yearInt = int(str(year).strip())
        except:
            yearInt = 0
        print('Year process: ', yearInt)
#  and
        if (INDEX >= IMPORT_FROM and INDEX < IMPORT_TO and yearInt >= 2018):
            print (r)
            survey_type = r['SurveyType']
            if 'responses' in r:
                response_count = int(r['responses'])
            else:
                response_count = 0
            total_responses_count += response_count
            update_survey(r['SurveyID'], r['SurveyName'], r['SurveyStatus'], survey_type, r['LastModified'], r['LastActivated'], response_count, descr = r.get('SurveyDescription', None))
            updateQuestions(r['SurveyID'], postgreConn)
            lastResponseGuid = updateResponses(postgreConn, r['SurveyID'], response_count)
            if lastResponseGuid != None:
                update_survey(r['SurveyID'], r['SurveyName'], r['SurveyStatus'], survey_type, r['LastModified'], r['LastActivated'], response_count, descr = r.get('SurveyDescription'), last_response_guid = lastResponseGuid)
            print('\n')
        INDEX = INDEX + 1
    print('Total survey count: ', len(allSurveys_Q.items()))
    print('Total response count: ', total_responses_count)
    print('Import completed for worker ', INSTANCE_ID, ' of ', TOTAL_INSTANCE)

# Retrieve list of surveys to be used for retrieving responses from Qualtrics API
def get_surveys():
    table = dynamodb.Table('surveys')
    pe = "id, guid, #lrg, #svi"
    fe = Attr('status').eq("Active")
    ean = { "#lrg": "last_response_guid", 
            "#svi": "survey_version_id"}
    response = table.scan(
        FilterExpression=fe,
        ProjectionExpression=pe,
        ExpressionAttributeNames=ean
    )
    return response


def iterate_result_pages(function_returning_response: typing.Callable, *args, **kwargs) -> typing.Generator:
    response = function_returning_response(*args, **kwargs)
    yield response["Items"]
    while "LastEvaluatedKey" in response:
        kwargs["ExclusiveStartKey"] = response["LastEvaluatedKey"]
        response = function_returning_response(*args, **kwargs)
        yield response["Items"]

    return

def iterate_paged_results(function_returning_response: typing.Callable, *args, **kwargs) -> typing.Iterator:
    return itertools.chain.from_iterable(iterate_result_pages(function_returning_response, *args, **kwargs))

def exists(table, hash):
    try:
        item = table.get_item(hash_key=hash)
    except boto.dynamodb.exceptions.DynamoDBKeyNotFoundError:
        item = None
    return item
    
def parseHtml(text):
    try:
        strtingToparse = "<!DOCTYPE html>"+str(text)+"</html>"
        page = lxml.html.document_fromstring(strtingToparse)
        return page.cssselect('body')[0].text_content()
    except lxml.etree.ParserError:
        return str(text)+" "

def connect():
    conn = None
    try:
        conn = psycopg2.connect(dbname='d2s5p9qouci5nq', user='mt_mark', password='p20b23186ddc5a7c477ca9728fbbe75b20d07e295fc83076e6ad3adb4a782a556', host='ec2-35-171-12-188.compute-1.amazonaws.com', port='5432', sslmode='require')
        print("Connected to POSTGRESS!")
    except (Exception, psycopg2.Error) as error :
        print ("Error while connecting to PostgreSQL", error)
    return conn

def get_relationship_questions(connection, survey_version_id):
    cursor = connection.cursor()
    sql = (
      """select q_number, question_type, relationship_type from survey_questions where survey_version_id = {0} and (relationship_type = 'trusted' or relationship_type = 'influential')"""
    ).format(survey_version_id)
    cursor.execute(sql)
    result = cursor.fetchall()
    return result


def get_survey_data(connection, survey_id):
    cursor = connection.cursor()
    sql = (
      """select * from surveys s inner join survey_versions sv on sv.id = s.survey_version_id  where s.guid = '{0}'"""
    ).format(survey_id)
    cursor.execute(sql)
    result = cursor.fetchall()
    return result
    
def getStaffId(connection, staffFullNamme):
    newId = -1
    staff_data = str(staffFullNamme).split(", ")
    if len(staff_data) == 2:
        cursor = connection.cursor()
        sql = """select * from staff_model_test where upper(staff_first_name) = %s and upper(staff_last_name) = %s;"""
        cursor.execute(sql, (staff_data[1].strip(), staff_data[0].strip()))
        result = cursor.fetchall()
        if len(result) > 0:
            newId = result[0][4]
            return newId
    return newId
    

def create_relationship_records(postgreConn, survey_guid, response_id, allTeachers, all_mentioned_idz, all_mentioned_numbers, studentFullName, studentId):
    postgress_survey_data = get_survey_data(postgreConn, survey_guid)
    # print('postgress_survey_data: ', postgress_survey_data)
    try:
        survey_version_id = postgress_survey_data[0][7]
    except:
        survey_version_id = -1
    
    important_questions = get_relationship_questions(postgreConn, survey_version_id)
    try:
        year = str(postgress_survey_data[0][4])[0:4]
        yearInt = int(year)
    except:
        year = None
    
    table = dynamodb.Table('new_student_staff_relationships')
    with table.batch_writer() as batch:
        for t in allTeachers:
            if allTeachers[t] > 0:
                relationshipType = getRelationShipType(important_questions, t, all_mentioned_idz, all_mentioned_numbers)
                staff_idz = getStaffId(postgreConn, str(t).upper())
                batch.put_item(Item={
                    'survey_guid': survey_guid,
                    'response_guid': response_id,
                    'guid': str(uuid.uuid1()),
                    'student_id': studentId,
                    'student_fullName': str(studentFullName).upper(),
                    'staff_id': staff_idz,
                    'staff_fullName': str(t).upper(),
                    'relationship': relationshipType,
                    'school_year': year,
                    'created_at': datetime.datetime.now().isoformat(),
                    'updated_at': datetime.datetime.now().isoformat(),
                    'other_name': None,
                    'kind': 'direct'
                })
         
def getRelationShipType(important_questions, t, all_mentioned_idz, all_mentioned_numbers):
    if important_questions == None:
        return 'related'
    q_id = all_mentioned_idz[t]
    q_nr = all_mentioned_numbers[t]
    type = question_belongs(important_questions, q_id, q_nr)
    if t == None:
        return 'related'
    if type == None:
        return 'related'
    
    return type[2]
    

def findResponseWithIdz(response_id, responsesWithIdz):
    if responsesWithIdz != None and responsesWithIdz.items() != None:
        for response_guid, response in responsesWithIdz.items():
            if response_guid == response_id:
                return response
    return None

def question_belongs(important_questions, q_number, q_id):
    # print("Cheking... ", q_number, q_id, important_questions)
    for d in important_questions:
        if d[0] == q_number or d[0] == q_id: 
            return d;
    return None
    
def create_assesment_record():
    table = dynamodb.Table('new_student_staff_relationships')
    table.put_item({
        guid: '',
        response_guid: '',
        survey_guid: '',
        source: '',
        responder_type: '',
        school_year: '',
        created_at: datetime.datetime.now().isoformat()
    })

if __name__ == "__main__":
    event = []
    context = []
    lambda_handler(event, context)
