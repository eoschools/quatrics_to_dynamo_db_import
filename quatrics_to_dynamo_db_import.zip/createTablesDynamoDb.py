from __future__ import print_function # Python 2/3 compatibility
from quatrics import quatrics
import psycopg2
import datetime
import boto3
import json
import decimal
from boto3.dynamodb.conditions import Key, Attr
import itertools
import typing
import lxml.html
import re


region = "us-west-2"
dynamoDbEndpoint = "https://dynamodb." + region + ".amazonaws.com"
dynamodb = boto3.resource('dynamodb', region_name=region, endpoint_url=dynamoDbEndpoint)

PREFIX = "new_"

def create_surveys():
    TABLE_NAME = PREFIX + "surveys"
    table = dynamodb.create_table(
    TableName=TABLE_NAME,
    KeySchema=[
        {
            'AttributeName': 'survey_guid',
            'KeyType': 'HASH'  #Partition key
        },
        {
            'AttributeName': 'name',
            'KeyType': 'RANGE'  #Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'survey_guid',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'name',
            'AttributeType': 'S'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 200,
        'WriteCapacityUnits': 500
    }
    )
    print("Table status:", table.table_status)
    print('Waiting for', TABLE_NAME, '...')
    #waiter = dynamodb.get_waiter('table_exists')
    #waiter.wait(TableName=TABLE_NAME)

def create_survey_questions():
    TABLE_NAME = PREFIX + "survey_questions"
    table = dynamodb.create_table(
    TableName=TABLE_NAME,
    KeySchema=[
        {
            'AttributeName': 'survey_guid',
            'KeyType': 'HASH'  #Partition key
        },
        {
            'AttributeName': 'q_id',
            'KeyType': 'RANGE'  #Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'survey_guid',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'q_id',
            'AttributeType': 'S'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 300,
        'WriteCapacityUnits': 600
    }
    )
    print("Table status:", table.table_status)
    print('Waiting for', TABLE_NAME, '...')
    #waiter = dynamodb.get_waiter('table_exists')
    #waiter.wait(TableName=TABLE_NAME)

def create_responses():
    TABLE_NAME = PREFIX + "responses"
    table = dynamodb.create_table(
    TableName=TABLE_NAME,
    KeySchema=[
        {
            'AttributeName': 'survey_guid',
            'KeyType': 'HASH'  #Partition key
        },
        {
            'AttributeName': 'response_guid',
            'KeyType': 'RANGE'  #Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'survey_guid',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'response_guid',
            'AttributeType': 'S'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 300,
        'WriteCapacityUnits': 900
    }
    )
    print("Table status:", table.table_status)
    print('Waiting for', TABLE_NAME, '...')
    #waiter = dynamodb.get_waiter('table_exists')
    #waiter.wait(TableName=TABLE_NAME)

def create_response_aswers():
    TABLE_NAME = PREFIX + "response_answers"
    table = dynamodb.create_table(
    TableName=TABLE_NAME,
    KeySchema=[
        {
            'AttributeName': 'response_guid',
            'KeyType': 'HASH'  #Partition key
        },
        {
            'AttributeName': 'order',
            'KeyType': 'RANGE'  #Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'response_guid',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'order',
            'AttributeType': 'N'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 200,
        'WriteCapacityUnits': 2000
    }
    )
    print("Table status:", table.table_status)
    print('Waiting for', TABLE_NAME, '...')
    #waiter = dynamodb.get_waiter('table_exists')
    #waiter.wait(TableName=TABLE_NAME)
    
def create_relationships():
    TABLE_NAME = PREFIX + "student_staff_relationships"
    table = dynamodb.create_table(
    TableName=TABLE_NAME,
    KeySchema=[
        {
            'AttributeName': 'response_guid',
            'KeyType': 'HASH'  #Partition key
        },
        {
            'AttributeName': 'guid',
            'KeyType': 'RANGE'  #Sort key
        }
    ],
    AttributeDefinitions=[
        {
            'AttributeName': 'response_guid',
            'AttributeType': 'S'
        },
        {
            'AttributeName': 'guid',
            'AttributeType': 'S'
        }
    ],
    ProvisionedThroughput={
        'ReadCapacityUnits': 200,
        'WriteCapacityUnits': 200
    }
    )
    print("Table status:", table.table_status)
    print('Waiting for', TABLE_NAME, '...')
    #waiter = dynamodb.get_waiter('table_exists')
    #waiter.wait(TableName=TABLE_NAME)

def testAlerming():
    alarming_words = open('alarming_words.txt','r').read().split("\n")
    # print(alarming_words)
    test1 = "When I’m faced with a challenge, I push through to complete whatever I set my mind to."
    res = any(ele in test1.lower() for ele in alarming_words) 
    print(test1, res)
    test2 = "When I’m faced with a challenge, I through to complete whatever I set my mind to."
    res = any(ele in test2.lower().split() for ele in alarming_words)
    print(test2, res)
    

def testFiltering():
    filtering_words = open('swear_words.txt','r').read().split("\n")
    # print(filtering_words)
    test1 = "Boy howdy I want to kill a shit-eating whatever teacher"
    test2 = "mi profesor es un hijo whatever de puta"
    for tag in filtering_words:
        test1 = re.sub(r'\b' + tag + r'\b', '[ ]', test1)
        print(test1, tag)
    print(str(test1), str(test1).index('[ ]') > -1)
    
    test3 = "mi profesor es un hijo de puta"

def lambda_handler(event, context):
    print('Creating tables...')
    create_surveys()
    create_survey_questions()
    create_responses()
    create_response_aswers()
    create_relationships()
    #testAlerming()
    #testFiltering()
	
if __name__ == "__main__":
    event = []
    context = []
    lambda_handler(event, context)
